package principal;

import clases.Aves;

public class Primera {

    public static void main(String[] args) {
        
        
        Aves animal = new Aves("loro", 5.5, "Jay-z valencia arevalo", 2005);
        animal.edad();
    }
    
}
